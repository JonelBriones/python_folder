# import the function that will return an instance of a connection
from flask_app.config.mysqlconnection import connectToMySQL
# model the class after the friend table from our database
from flask import flash
# replace Name for method name


class Message:
    def __init__(self, data):
        self.id = data['id']
        self.user_id = data['user_id']
        self.message = data['message']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
    # Now we use class methods to query our database

    @classmethod
    def save(cls, data):
        query = "INSERT INTO messages ( user_id, message , created_at, updated_at ) VALUES ( %(user_id)s, %(message)s , NOW() , NOW() );"
        # data is a dictionary that will be passed into the save method from server.py
        print(query)
        return connectToMySQL('private_wall').query_db(query, data)

    @classmethod
    def get_my_messages(cls, data):
        query = "SELECT * FROM users JOIN messages ON messages.user_id = users.id WHERE NOT user_id = %(id)s;"
        # query = "SELECT * FROM messages WHERE NOT user_id = %(id)s;"
        # make sure to call the connectToMySQL function with the schema you are targeting. #(change name in '  ')
        results = connectToMySQL('private_wall').query_db(query, data)
        # Create an empty list to append our instances of friends
        users = []
        # Iterate over the db results and create instances of friends with cls.
        for user in results:
            users.append(cls(user))
        return users
